console.log('Service worker started'); // Debug log

// Load Supabase client library
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// Initialize Supabase client with better configuration for service workers
const SUPABASE_URL = 'https://gxpffhxrgkbgwukrlrcl.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4cGZmaHhyZ2tiZ3d1a3JscmNsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzk0ODUzODIsImV4cCI6MjA1NTA2MTM4Mn0.YGNYi-7uQF7-1KIiEM8plpyGpfXoXhck66PhfhoatJg';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  realtime: {
    params: {
      eventsPerSecond: 10
    },
    timeout: 30000, // Increase timeout for service worker
  },
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false
  }
});

console.log('Supabase client initialized:', supabase);

// Store active subscription
let activeSubscription = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10; // Increased max attempts
const INITIAL_RECONNECT_DELAY = 1000; // Start with 1 second
let isReconnecting = false;
let heartbeatInterval = null;
let connectionCheckInterval = null;

// Function to subscribe to real-time updates
function subscribeToMessages(callback) {
  console.log('Subscribing to real-time updates...');
  
  // Unsubscribe from existing subscription if any
  if (activeSubscription) {
    console.log('Removing existing subscription...');
    try {
      supabase.removeChannel(activeSubscription);
    } catch (e) {
      console.error('Error removing channel:', e);
    }
    activeSubscription = null;
  }
  
  // Reset reconnection flag
  isReconnecting = false;
  
  // Create a unique channel name to avoid conflicts
  const channelName = `messages-${Date.now()}`;
  console.log('Creating channel:', channelName);
  
  const channel = supabase.channel(channelName, {
    config: {
      broadcast: { self: true, ack: false },
      presence: { key: '' }
    }
  });
  
  channel
    .on(
      'postgres_changes',
      { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages' 
      },
      (payload) => {
        console.log('New message received:', payload.new);
        callback(payload.new);
      }
    )
    .subscribe((status, err) => {
      console.log('Subscription status:', status, err ? err : '');
      
      switch(status) {
        case 'SUBSCRIBED':
          console.log('Successfully subscribed to messages!');
          reconnectAttempts = 0;
          isReconnecting = false;
          break;
          
        case 'CHANNEL_ERROR':
          console.error('Channel error:', err);
          if (!isReconnecting) {
            handleReconnection(callback);
          }
          break;
          
        case 'CLOSED':
          console.log('Channel closed');
          if (!isReconnecting) {
            handleReconnection(callback);
          }
          break;
          
        case 'TIMED_OUT':
          console.log('Subscription timed out');
          if (!isReconnecting) {
            handleReconnection(callback);
          }
          break;
      }
    });
  
  activeSubscription = channel;
  return channel;
}

// Handle reconnection logic with exponential backoff
function handleReconnection(callback) {
  if (isReconnecting) return;
  
  if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
    isReconnecting = true;
    reconnectAttempts++;
    
    // Exponential backoff with jitter
    const baseDelay = INITIAL_RECONNECT_DELAY * Math.pow(1.5, reconnectAttempts - 1);
    const jitter = Math.random() * 1000;
    const delay = Math.min(baseDelay + jitter, 30000); // Cap at 30 seconds
    
    console.log(`Attempting to reconnect (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}) in ${Math.round(delay/1000)} seconds...`);
    
    setTimeout(() => {
      console.log('Reconnecting...');
      isReconnecting = false;
      subscribeToMessages(callback);
    }, delay);
  } else {
    console.error('Max reconnection attempts reached. Will try again after longer delay.');
    // Reset attempts after a longer cooldown (5 minutes)
    setTimeout(() => {
      console.log('Resetting reconnection attempts...');
      reconnectAttempts = 0;
      if (!activeSubscription) {
        subscribeToMessages(callback);
      }
    }, 5 * 60 * 1000);
  }
}

// Function to show a notification
function showNotification(message) {
  console.log('Showing notification:', message);
  
  // Strip HTML tags for cleaner notification
  const strippedText = message.text.replace(/<[^>]*>/g, '').substring(0, 200);
  
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon256.png',
    title: `New Message from ${message.username}`,
    message: strippedText,
    priority: 2
  });
}

// Start real-time subscription
async function startRealTimeUpdates() {
  console.log('Starting real-time updates...');
  
  try {
    // Clear any existing subscription
    if (activeSubscription) {
      try {
        supabase.removeChannel(activeSubscription);
      } catch (e) {
        console.error('Error removing channel:', e);
      }
      activeSubscription = null;
    }
    
    // Wait a bit to ensure clean state
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const subscription = subscribeToMessages(async (newMessage) => {
      try {
        const { currentUserId } = await chrome.storage.local.get('currentUserId');
        if (newMessage.user_id !== currentUserId) {
          chrome.storage.local.get('featureEnabled', (result) => {
            console.log('Feature enabled state:', result.featureEnabled);
            if (result.featureEnabled) {
              showNotification(newMessage);
            }
          });
        } else {
          console.log('Ignoring own message:', newMessage);
        }
      } catch (error) {
        console.error('Error processing new message:', error);
      }
    });
    
    activeSubscription = subscription;
  } catch (error) {
    console.error('Error in startRealTimeUpdates:', error);
    handleReconnection(async (newMessage) => {
      // Recreate the callback
      const { currentUserId } = await chrome.storage.local.get('currentUserId');
      if (newMessage.user_id !== currentUserId) {
        chrome.storage.local.get('featureEnabled', (result) => {
          if (result.featureEnabled) {
            showNotification(newMessage);
          }
        });
      }
    });
  }
}

// Heartbeat to keep service worker alive
function startHeartbeat() {
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
  }
  
  heartbeatInterval = setInterval(() => {
    console.log('Service worker heartbeat', new Date().toISOString());
    
    // Check if we need to reconnect
    if (!activeSubscription && !isReconnecting) {
      console.log('No active subscription, attempting to reconnect...');
      startRealTimeUpdates();
    }
  }, 45 * 1000); // Run every 45 seconds
}

// Check connection status periodically
function startConnectionCheck() {
  if (connectionCheckInterval) {
    clearInterval(connectionCheckInterval);
  }
  
  connectionCheckInterval = setInterval(() => {
    if (activeSubscription) {
      // Check if the channel is still in a valid state
      try {
        // You can add more sophisticated checks here if needed
        console.log('Connection check: Channel exists');
      } catch (e) {
        console.log('Connection check failed, reconnecting...');
        startRealTimeUpdates();
      }
    }
  }, 30 * 1000); // Check every 30 seconds
}

// Clean up on service worker shutdown
self.addEventListener('unload', () => {
  console.log('Service worker unloading, cleaning up...');
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
  }
  if (connectionCheckInterval) {
    clearInterval(connectionCheckInterval);
  }
  if (activeSubscription) {
    try {
      supabase.removeChannel(activeSubscription);
    } catch (e) {
      console.error('Error removing channel on unload:', e);
    }
    activeSubscription = null;
  }
});

// Reinitialize on service worker restart
chrome.runtime.onStartup.addListener(() => {
  console.log('Service worker started. Reinitializing Supabase...');
  startHeartbeat();
  startConnectionCheck();
  setTimeout(() => {
    startRealTimeUpdates();
  }, 3000); // Delay initial connection
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed. Initializing Supabase...');
  startHeartbeat();
  startConnectionCheck();
  setTimeout(() => {
    startRealTimeUpdates();
  }, 3000);
});

// Handle when the extension wakes up
chrome.runtime.onConnect.addListener((port) => {
  console.log('Port connected:', port.name);
  if (!activeSubscription && !isReconnecting) {
    startRealTimeUpdates();
  }
});

// Initialize with retry logic
async function initialize() {
  console.log('Initializing service worker...');
  startHeartbeat();
  startConnectionCheck();
  
  // Try to connect immediately
  try {
    await startRealTimeUpdates();
  } catch (error) {
    console.error('Initial connection failed:', error);
    // Retry after longer delay
    setTimeout(() => {
      startRealTimeUpdates();
    }, 5000);
  }
}

// Start initialization
initialize();