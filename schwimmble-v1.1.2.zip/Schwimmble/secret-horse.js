// Chance configuration
const CHANCE = 1 / 25000;
const INTERVAL = 5000; // 5 seconds in milliseconds

// Track last execution to prevent double-triggering
let lastExecutionTime = 0;

// Set up the interval timer
setInterval(() => {
    // Generate random number between 0 and 1
    const randomValue = Math.random();

    // Check if we hit the 1/2500 chance
    if (randomValue < CHANCE) {
        // Prevent execution if we just ran one (anti-spam)
        const now = Date.now();
        if (now - lastExecutionTime > 1000) { // At least 1 second between executions
            lastExecutionTime = now;
            executeRandomCode();
        }
    }
}, INTERVAL);


// Function that runs your custom JavaScript on the webpage
function executeRandomCode() {

    const surpriseElement = document.createElement('div');

    // Set its content
    surpriseElement.innerHTML = `
    <div style="
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      padding: 10px;
      border-radius: 10px;
      box-shadow: 0 0 30px rgba(0,0,0,0.5);
      z-index: 999999;
      font-family: Arial, sans-serif;
      text-align: left;
      min-width: 450px;
    ">
    <button style="
        background: #b60000;
        color: white;
        border: 2px;
        padding: 3px 2.5px;
        cursor: pointer;
        font-size: 16px;
        top: 10px;
        position: absolute;
      " onclick="this.parentElement.parentElement.remove()">X</button>
      
      <p style="position:absolute; width:60%; top:30px;">Please stand by for a scheduled Horse Moment.</p>
      <img src="https://i.imgur.com/eAr2AuJ.png" height="200em" style="left: 100%;position: sticky;">
      <p style="position:absolute;top: 45%;">You will now contemplate and reflect.</p>
      <p style="position:absolute;top: 73%;">This is a time of seriousness.</p>
    </div>
  `;

    // Add a semi-transparent backdrop
    const backdrop = document.createElement('div');
    backdrop.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 999998;
  `;

    // Add to page
    document.body.appendChild(backdrop);
    document.body.appendChild(surpriseElement);

    // Make the close button remove both
    surpriseElement.querySelector('button').addEventListener('click', () => {
        surpriseElement.remove();
        backdrop.remove();
    });


}