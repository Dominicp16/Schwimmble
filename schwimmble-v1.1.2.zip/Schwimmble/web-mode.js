const randomPictureContainerWeb = document.getElementById('random-picture-container-web-mode');
const pictureInfoWeb = document.getElementById('picture-info-web-mode');
const randomPictureWeb = document.getElementById('random-picture-web-mode');

// Web mode message sending
async function sendMessageWeb(message) {
  if (!message.trim()) return null;

  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      alert('You must be logged in to send messages');
      return null;
    }

    const { data, error } = await supabase
      .from('messages')
      .insert([{
        text: message,
        user_id: user.id,
        username: user.username || 'Anonymous'
      }])
      .select();

    if (error) throw error;
    return data[0];
  } catch (error) {
    console.error('Error sending message:', error);
    alert('Failed to send message');
    return null;
  }
}

// Override the send button click handler for web mode
document.addEventListener('DOMContentLoaded', () => {
  const sendButton = document.getElementById('send-button');
  const messageInput = document.getElementById('message-input');

  if (sendButton) {
    sendButton.addEventListener('click', async () => {
      const message = messageInput.value;
      if (message) {
        const newMessage = await sendMessageWeb(message);
        if (newMessage) {
          messageInput.value = '';
        }
      }
    });
  }

  if (messageInput) {
    messageInput.addEventListener('keydown', async (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        const message = messageInput.value;
        if (message) {
          const newMessage = await sendMessageWeb(message);
          if (newMessage) {
            messageInput.value = '';
          }
        }
      }
    });
  }
});


async function webModeRandomPicture() {
  const names = ['shadow', 'skye', 'dixie', 'sami', 'rylen']; // List of names in the desired order
  const maxNumbers = [22, 29, 32, 26, 1]; // Corresponding maximum numbers for each name

  function getRandomInt(max) {
    return Math.floor(Math.random() * max) + 1;
  }


  let i = Math.floor(Math.random() * names.length);

  let name = names[i]
  let number = getRandomInt(maxNumbers[i])

  let imageUrl = `https://raw.githubusercontent.com/Dominicp16/cates-for-schwimmble/main/${name}${number}.jpg`;

  randomPictureWeb.src = imageUrl;
  randomPictureContainerWeb.style.display = 'block';

  // Update the text below the image
  pictureInfoWeb.textContent = `${name} picture #${number}`;
}

webModeRandomPicture()