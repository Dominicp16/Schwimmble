// Initialize Supabase client
const SUPABASE_URL = 'https://gxpffhxrgkbgwukrlrcl.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4cGZmaHhyZ2tiZ3d1a3JscmNsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzk0ODUzODIsImV4cCI6MjA1NTA2MTM4Mn0.YGNYi-7uQF7-1KIiEM8plpyGpfXoXhck66PhfhoatJg';

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Function to save session to localStorage
async function saveSession(session) {
  localStorage.setItem('supabase_session', JSON.stringify(session));
  console.log('Session saved:', session); // Debugging
}

// Function to get session from localStorage
async function getSession() {
  const session = JSON.parse(localStorage.getItem('supabase_session'));
  console.log('Session retrieved:', session); // Debugging
  return session || null;
}

// Function to clear session from localStorage
async function clearSession() {
  console.log('Clearing session from localStorage...');
  localStorage.removeItem('supabase_session');
  console.log('Session cleared:', localStorage.getItem('supabase_session')); // Should log `null`
}

async function login(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    console.error('Login error:', error.message || error);
    return { error };
  }

  // Save the session
  await saveSession(data.session);
  await chrome.storage.local.set({ currentUserId: data.user.id });
  return data.user;
}

// Function to handle signup
async function signup(email, password, username) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) {
    console.error('Signup error:', error.message || error);
    return error;
  }

  // Save the username to the profiles table
  const { error: profileError } = await supabase
    .from('profiles')
    .insert([{ id: data.user.id, username }]);

  if (profileError) {
    console.error('Error saving profile:', profileError.message || profileError);
    return profileError;
  }

  await saveSession(data.session);
  return data.user;
}


// Function to handle logout
async function logout() {
  const { error } = await supabase.auth.signOut();
  if (error) {
    console.error('Logout error:', error.message || error);
    return error;
  }
  await clearSession(); // Clear the session
  await chrome.storage.local.remove('currentUserId'); // Clear the current user's ID
  return true;
}

// Function to check if a user is logged in
async function checkAuth() {
  const session = await getSession();
  if (session) {
    console.log('Setting session with tokens:', {
      access_token: session.access_token,
      refresh_token: session.refresh_token,
    }); // Debugging
    const { data, error } = await supabase.auth.setSession({
      access_token: session.access_token,
      refresh_token: session.refresh_token,
    });
    if (error) {
      console.error('Auth check error:', error.message || error); // Debugging
      // Attempt to refresh the session
      const { data: refreshedData, error: refreshError } = await supabase.auth.refreshSession();
      if (refreshError) {
        console.error('Refresh session error:', refreshError.message || refreshError); // Debugging
        return null;
      }
      await saveSession(refreshedData.session);
      return refreshedData.user;
    }
    return data.user;
  }
  return null;
}

// Function to send a message
async function sendMessage(message) {
  if (message.length > 65536) {
    console.error('Message exceeds maximum length');
    return null;
  }

  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError) {
    console.error('Error fetching user:', userError.message || userError);
    return null;
  }

  // Fetch the username from the profiles table
  const { data: profileData, error: profileError } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', userData.user.id)
    .single();

  if (profileError) {
    console.error('Error fetching profile:', profileError.message || profileError);
    return null;
  }

  // Include the current timestamp
  const createdAt = new Date().toISOString();

  const { data, error } = await supabase
    .from('messages')
    .insert([{
      text: message,
      user_id: userData.user.id,
      username: profileData.username,
      created_at: createdAt // Include the timestamp
    }])
    .select(); // Return the inserted message

  if (error) {
    console.error('Error sending message:', error.message || error);
    return null;
  } else {
    console.log('Message sent:', data);
    return data[0]; // Return the newly sent message
  }
}

// Function to fetch messages
async function fetchMessages() {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .order('created_at', { ascending: true });

  if (error) {
    console.error('Error fetching messages:', error.message || error);
  } else {
    return data;
  }
}

// Function to load messages
async function loadMessages() {
  const messages = await fetchMessages();
  const messagesDiv = document.getElementById('messages');
  messagesDiv.innerHTML = messages
    .map(
      (msg) => `
        <div>
          <strong>〈${msg.username}〉:</strong> ${msg.text}
        </div>
      `
    )
    .join('');
}

// Function to subscribe to real-time updates
function subscribeToMessages(callback) {
  return supabase
    .channel('messages') // Unique channel name
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages' },
      (payload) => {
        console.log('New message received:', payload.new); // Debugging
        callback(payload.new); // Call the callback with the new message
      }
    )
    .subscribe();
}

// Function to unsubscribe from real-time updates
function unsubscribeFromMessages(subscription) {
  supabase.removeChannel(subscription);
}

async function getMessageCount() {
  const { count, error } = await supabase
    .from('messages')
    .select('*', { count: 'exact', head: true });

  if (error) {
    console.error('Error getting message count:', error);
    return 0;
  }
  return count;
}

async function fetchPrivilegedUsers() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/Dominicp16/Schwimmble/main/privileged-users.json');
    if (!response.ok) throw new Error('Failed to fetch');
    return await response.json();
  } catch (error) {
    console.error('Error fetching privileged users:', error);
    return [
      "86689bb0-9800-4230-a2ce-f83c81558679",
      "de5a9215-8e55-436b-aec6-42cdecdb6cf7",
    ]
  }
}

// Attach functions to the window object
window.supabaseFunctions = {
  login,
  signup,
  logout,
  checkAuth,
  sendMessage,
  fetchMessages,
  subscribeToMessages,
  unsubscribeFromMessages,
  getMessageCount,
  fetchPrivilegedUsers,
};