document.addEventListener('DOMContentLoaded', async () => {
  const toggleRandomPictureCheckbox = document.getElementById('toggle-random-picture');
  const randomPictureContainer = document.getElementById('random-picture-container');
  const pictureInfo = document.getElementById('picture-info');
  const randomPicture = document.getElementById('random-picture');
  const authSection = document.getElementById('auth-section');
  const messagingSection = document.getElementById('messaging-section');
  const emailInput = document.getElementById('email-input');
  const passwordInput = document.getElementById('password-input');
  const usernameInput = document.getElementById('username-input');
  const loginButton = document.getElementById('login-button');
  const signupButton = document.getElementById('signup-button');
  const logoutButton = document.getElementById('logout-button');
  const authError = document.getElementById('auth-error');
  const messagesDiv = document.getElementById('messages');
  const messageInput = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');
  const charCounter = document.getElementById('char-counter');
  const bigCounter = document.getElementById('tag-counter');
  const bigTagCountElement = document.getElementById('big-tag-count');
  const bigTagMaxElement = document.getElementById('big-tag-max');
  const versionNumber = document.getElementById('version-number');
  const messageCountElement = document.getElementById('message-count');
  const fullMessageCountElement = document.getElementById('full-message-count-ui');
  const contextMenu = document.getElementById('context-menu');
  const contextMessageId = document.getElementById('context-message-id');
  const contextUserId = document.getElementById('context-user-id');
  const contextDate = document.getElementById('context-date');
  const contextDelete = document.getElementById('context-delete');

  // Styling menu elements
  const toggleStylingMenuCheckbox = document.getElementById('toggle-styling-menu');
  const stylingMenu = document.getElementById('styling-menu');

  // Styling menu buttons
  const boldButton = document.getElementById('bold-button');
  const italicButton = document.getElementById('italic-button');
  const underlineButton = document.getElementById('underline-button');
  const strikethroughButton = document.getElementById('strikethrough-button');
  const hyperlinkButton = document.getElementById('hyperlink-button');
  const superscriptButton = document.getElementById('superscript-button');
  const subscriptButton = document.getElementById('subscript-button');
  const smallButton = document.getElementById('small-button');
  const bigButton = document.getElementById('big-button');
  const colourButton = document.getElementById('colour-button');
  const overlineButton = document.getElementById('overline-button');
  const codeButton = document.getElementById('code-button');
  const lineBreakButton = document.getElementById('line-break-button');
  const highlightButton = document.getElementById('highlight-button');
  const tooltipButton = document.getElementById('tooltip-button');
  const cursorButton = document.getElementById('cursor-button');
  const usernameButton = document.getElementById('username-button');
  const thinButton = document.getElementById('thin-button');
  const discreetHyperlinkButton = document.getElementById('discreet-hyperlink-button');
  const smallerButton = document.getElementById('smaller-button');
  const biggerButton = document.getElementById('bigger-button');

  let messagesSubscription;
  const sentMessageIds = new Set(); // Track IDs of messages already displayed

  const messageIdMap = new Map(); // Maps message elements to their IDs

  let loginAttempts = 0;
  let lastFailedAttemptTime = 0;
  let currentWaitTime = 0;
  let currentLockoutLevel = 0;
  let lockoutEndTime = 0;
  let isLoginLocked = false;

  const MAX_BIG_TAGS = 6; // Maximum allowed <big> tags per message

  let currentMessageId = null;
  let currentMessageUserId = null;

  // Remove the hardcoded privilegedUsers array and replace with:
  let privilegedUsers = [
    "de5a9215-8e55-436b-aec6-42cdecdb6cf7",
    //"86689bb0-9800-4230-a2ce-f83c81558679",
  ];

  // Check if user is already logged in
  const user = await checkAuth();
  if (user) {
    currentUser = user;
    showMessagingSection();
    await loadMessages(); // Load existing messages
    messagesSubscription = subscribeToMessages(handleNewMessage); // Subscribe to real-time updates
    checkMessageCountVisibility()
  }

  // Login button click
  loginButton.addEventListener('click', async () => {
    if (checkLoginLock()) return;

    const email = emailInput.value;
    const password = passwordInput.value;
    try {
      const result = await login(email, password);
      if (result.error) {
        updateLoginAttempts(true);
        authError.textContent = result.error.message;

        // Show remaining attempts when not locked
        if (!isLoginLocked) {
          const remainingAttempts = Math.max(0, 4 - loginAttempts);
          if (remainingAttempts > 0) {
            authError.textContent += ` (${remainingAttempts} attempts remaining)`;
          }
        }
      } else {
        updateLoginAttempts(false);
        currentUser = result; // Set the current user
        showMessagingSection(); // Show the messaging section
        await loadMessages(); // Load existing messages
        messagesSubscription = subscribeToMessages(handleNewMessage); // Subscribe to real-time updates
      }
    } catch (error) {
      updateLoginAttempts(true);
      authError.textContent = "Login failed";
    }
    checkMessageCountVisibility()
  });

  // Signup button click
  signupButton.addEventListener('click', async () => {
    const email = emailInput.value;
    const password = passwordInput.value;
    const username = usernameInput.value; // Get username
    const result = await signup(email, password, username);
    if (result.error) {
      authError.textContent = result.error.message;
    } else {
      authError.textContent = 'Please check your email to confirm your account. The link sent will show up as blocked, but you can then open the extension again and log in.';
    }
    checkMessageCountVisibility()
  });

  // Logout button click
  logoutButton.addEventListener('click', async () => {
    await logout();
    showAuthSection();
    checkMessageCountVisibility()
    // Unsubscribe from real-time updates
    if (messagesSubscription) {
      unsubscribeFromMessages(messagesSubscription);
    }
  });

  const MAX_MESSAGE_LENGTH = 65536;

  // Show messaging section
  function showMessagingSection() {
    authSection.style.display = 'none';
    messagingSection.style.display = 'block';
    checkMessageCountVisibility()
  }

  // Show auth section
  function showAuthSection() {
    authSection.style.display = 'block';
    messagingSection.style.display = 'none';
    updateLoginAttempts(false);
    checkMessageCountVisibility()
  }

  // Function to fetch messages
  async function fetchMessages() {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching messages:', error.message || error);
    } else {
      return data;
    }
  }

  function splitString(inputString, splitString) {
    const splitIndex = inputString.indexOf(splitString);

    if (splitIndex === -1) {
      return ["", inputString];
    }

    const beforeSplit = inputString.slice(0, splitIndex);
    const afterSplit = inputString.slice(splitIndex + splitString.length);

    return [beforeSplit, afterSplit];
  }

  // Function to format a date as dd/mm/yy
  function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0'); // Ensure two digits
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = String(date.getFullYear()).slice(-2); // Get last two digits of the year
    return `${day}/${month}/${year}`;
  }

  function autocorrectGodToGlodSimple(text) {
    return text.replace(/\bGod\b/gi, 'Glod');
  }

  // Load messages
  async function loadMessages() {
    const messages = await fetchMessages();

    // Store privileged status at load time
    const { currentUserId } = await chrome.storage.local.get('currentUserId');
    const isPrivileged = currentUserId && privilegedUsers.includes(currentUserId);

    messagesDiv.innerHTML = messages
      .map((msg) => {
        const messageDate = new Date(msg.created_at);
        const now = new Date();
        const isMoreThanADayOld = (now - messageDate) > 24 * 60 * 60 * 1000;
        const dateString = isMoreThanADayOld ? ` ${formatDate(messageDate)}` : '';

        msg.text = autocorrectGodToGlodSimple(msg.text);

        const canDelete = isPrivileged || currentUserId === msg.user_id;
        return `
          <div class="message-container" data-message-id="${msg.id}" data-can-delete="${canDelete}">
            ${splitString(msg.text, "</username>")[0]}<strong class="${msg.user_id === currentUser.id ? 'message-self' : 'message'}">〈${msg.username}〉: </strong> ${replaceEmojis(splitString(msg.text, "</username>")[1])} 
            <small><em>(${new Date(msg.created_at).toLocaleTimeString()}${dateString})</em></small>
          </div>
        `;
      })
      .join('');

    // Add delete handlers to all loaded messages
    messagesDiv.querySelectorAll('.message').forEach((messageElement) => {
      const messageId = messageElement.dataset.messageId;
      addDeleteMessageHandler(messageElement, messageId);
    });

    // Add context menu listeners to all messages
    messagesDiv.querySelectorAll('.message-container').forEach((messageElement) => {
      messageElement.addEventListener('contextmenu', (e) => {
        showContextMenu(e, messageElement);
      });
    });

    // Add hover listeners and store message IDs in the map
    messagesDiv.querySelectorAll('.message').forEach((messageElement, index) => {
      const messageId = messages[index].id; // Get the message ID from the fetched data
      messageIdMap.set(messageElement, messageId); // Store the ID in the map

      addHoverListeners(messageElement);
    });

    // Only attach event listener to containers that can be deleted
    document.querySelectorAll('.message-container[data-can-delete="true"]').forEach(el => {
      el.addEventListener('contextmenu', showCustomContextMenu);
    });

    // Add hover listeners to all messages
    messagesDiv.querySelectorAll('.message-container').forEach((messageElement) => {
      let hasPermission = false;
      let messageId = messageElement.dataset.messageId;

      // Check permissions on hover
      messageElement.addEventListener('mouseenter', async () => {
        hasPermission = await checkMessagePermissions(messageId);

        // Only add contextmenu listener if user has permission
        if (hasPermission) {
          messageElement.addEventListener('contextmenu', handleContextMenu);
        }
      });

      // Remove contextmenu listener when mouse leaves
      messageElement.addEventListener('mouseleave', () => {
        if (hasPermission) {
          messageElement.removeEventListener('contextmenu', handleContextMenu);
        }
      });
    });

    // Add single contextmenu listener to the messages container
    messagesDiv.addEventListener('contextmenu', async (e) => {
      // Find the closest message container
      const messageElement = e.target.closest('.message-container');
      if (!messageElement) return;

      const messageId = messageElement.dataset.messageId;
      const messageUserId = messageElement.dataset.userId;

      // Get current user
      const { currentUserId } = await chrome.storage.local.get('currentUserId');
      if (!currentUserId) return; // Let browser handle it

      // Check if user is privileged or owns the message
      const isPrivileged = privilegedUsers.includes(currentUserId);
      const isOwner = currentUserId === messageUserId;

      if (!isPrivileged && !isOwner) return; // Let browser handle it

      // Only prevent default if we're showing our menu
      //e.preventDefault();

      // Show our custom context menu
      contextMessageId.textContent = `Message ID: ${messageId}`;
      contextUserId.textContent = `User ID: ${messageUserId}`;
      contextDate.textContent = `Date: ${new Date().toLocaleString()}`; // Or fetch actual date if needed

      contextMenu.style.display = 'block';
      contextMenu.style.left = `${e.clientX}px`;
      contextMenu.style.top = `${e.clientY}px`;

      currentMessageId = messageId;
      currentMessageUserId = messageUserId;
    });

    await updateMessageCount();

    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Scroll to the bottom
  }

  function formatTimestamp(timestamp) {
    const now = new Date();
    const messageDate = new Date(timestamp);
    const isToday = now.toDateString() === messageDate.toDateString();

    if (isToday) {
      return messageDate.toLocaleTimeString();
    } else {
      return messageDate.toLocaleDateString();
    }
  }

  // Function to handle new messages
  function handleNewMessage(newMessage) {
    if (sentMessageIds.has(newMessage.id)) {
      // Skip if the message has already been displayed
      return;
    }
    sentMessageIds.add(newMessage.id); // Track the message ID

    const messageElement = document.createElement('div');
    messageElement.dataset.messageId = newMessage.id; // Add data-message-id attribute
    const timestamp = new Date(newMessage.created_at).toLocaleTimeString();
    messageElement.id = 'message-container'

    // Replace emoji keywords with emoji images
    const messageText = replaceEmojis(newMessage.text);

    messageElement.innerHTML = `
       ${splitString(messageText, "</username>")[0]}<strong class="${newMessage.user_id === currentUser.id ? 'message-self' : 'message'}">〈${newMessage.username}〉: </strong> ${splitString(messageText, "</username>")[1]}
      <small><em>(${timestamp})</em></small>
    `;
    messageElement.innerHTML = autocorrectGodToGlodSimple(messageElement.innerHTML);
    messagesDiv.appendChild(messageElement);

    // Add the delete handler to the message element
    addDeleteMessageHandler(messageElement, newMessage.id);

    // Add hover listeners to the new message
    addHoverListeners(messageElement);

    // Append the new message to the messages container
    messagesDiv.appendChild(messageElement);

    // Wait for all images in the message to load before scrolling
    const images = messageElement.getElementsByTagName('img');
    let imagesLoaded = 0;

    if (images.length > 0) {
      for (const img of images) {
        img.onload = () => {
          imagesLoaded++;
          if (imagesLoaded === images.length) {
            // All images have loaded, scroll to the bottom
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
          }
        };
      }
    } else {
      // No images, scroll immediately
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    // Use a MutationObserver to scroll to the bottom after the message is fully rendered
    const observer = new MutationObserver((mutationsList, observer) => {
      for (const mutation of mutationsList) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          // Scroll to the bottom after the new message is added
          messagesDiv.scrollTop = messagesDiv.scrollHeight;
          observer.disconnect(); // Stop observing once the scroll is done
        }
      }
    });



    // Start observing the messages container for changes
    observer.observe(messagesDiv, { childList: true });
  }

  stylingMenu.style.display = 'none'

  // Toggle styling menu visibility
  toggleStylingMenuCheckbox.addEventListener('change', () => {
    stylingMenu.style.display = toggleStylingMenuCheckbox.checked ? 'flex' : 'none';
  });


  // Function to apply formatting to selected text
  function applyFormatting(tag) {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const formattedText = `<${tag}>${selectedText}</${tag}>`;
      messageInput.setRangeText(formattedText, start, end, 'end');
    }
  }

  // Add keybind event listeners
  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.metaKey) { // Check for Alt (Windows/Linux) or Option (Mac)
      const messageInput = document.getElementById('message-input');
      if (messageInput === document.activeElement) { // Ensure the input field is focused
        switch (event.key.toLowerCase()) {
          case 'b': // Bold (Alt+B or Option+B)
            applyFormatting('b');
            event.preventDefault(); // Prevent default browser behavior
            break;
          case 'i': // Italic (Alt+I or Option+I)
            applyFormatting('i');
            event.preventDefault();
            break;
          case 'u': // Underline (Alt+U or Option+U)
            applyFormatting('u');
            event.preventDefault();
            break;
          case 's': // Strikethrough (Alt+S or Option+S)
            applyFormatting('s');
            event.preventDefault();
            break;
          case 'l': // Line break (Alt+L or Option+L)
            addLineBreak();
            event.preventDefault();
            break;
          case '.': // Superscript (Alt+. or Option+.)
            applyFormatting('sup');
            event.preventDefault();
            break;
          case ',': // Subscript (Alt+, or Option+,)
            applyFormatting('sub');
            event.preventDefault();
            break;
          case 'h': // Hyperlink (Alt+h or Option+h)
            addHyperlink();
            event.preventDefault();
            break;
        }
      }
    }
  });

  // Function to add a hyperlink
  function addHyperlink() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const url = prompt('Enter the URL:');
      if (url) {
        const hyperlink = `<a href="${url}" target="_blank">${selectedText}</a>`;
        messageInput.setRangeText(hyperlink, start, end, 'end');
      }
    }
  }

  // Function to add a colour
  function addColour() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const colour = prompt('Enter the colour:');
      if (colour) {
        const coloured = `<span style="color:${colour};">${selectedText}</span>`;
        messageInput.setRangeText(coloured, start, end, 'end');
      }
    }
  }

  // Function to add an overline
  function addOverline() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const overline = `<span style="text-decoration:overline;">${selectedText}</span>`;
      messageInput.setRangeText(overline, start, end, 'end');
    }
  }

  // Function to add a line break
  function addLineBreak() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;

    const broken = `<br>‌  `;
    messageInput.setRangeText(broken, start, end, 'end');
  }

  // Function to add a highlight
  function addHighlight() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const highlight = prompt('Enter the highlight colour:');
      if (highlight) {
        const highlighted = `<mark style="background-color:${highlight};">${selectedText}</mark>`;
        messageInput.setRangeText(highlighted, start, end, 'end');
      }
    }
  }

  // Function to add a tooltip
  function addTooltip() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const tooltip = prompt('Enter the tooltip:');
      if (tooltip) {
        const tooltipped = `<span title="${tooltip}">${selectedText}</span>`;
        messageInput.setRangeText(tooltipped, start, end, 'end');
      }
    }
  }

  // Function to add a cursor
  function addCustomCursor() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const cursor = prompt('Enter the cursor:');
      if (cursor) {
        const customCursor = `<cc type="${cursor}">${selectedText}</cc>`;
        messageInput.setRangeText(customCursor, start, end, 'end');
      }
    }
  }

  // Function to add the username
  function addUsername() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;

    const username = `</username>`;
    messageInput.setRangeText(username, start, end, 'end');
  }

  // Function to add a discreet hyperlink
  function addDiscreetHyperlink() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const url = prompt('Enter the URL:');
      if (url) {
        const hyperlink = `<a href="${url}" target="_blank" style="text-decoration:none; color:white;">${selectedText}</a>`;
        messageInput.setRangeText(hyperlink, start, end, 'end');
      }
    }
  }

  // Function make text smaller
  function addSmaller() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const smaller = `<small><small>${selectedText}</small></small>`;
      messageInput.setRangeText(smaller, start, end, 'end');
    }
  }

  // Function make text bigger
  function addBigger() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const bigger = `<big><big>${selectedText}</big></big>`;
      messageInput.setRangeText(bigger, start, end, 'end');
    }
  }

  // Add event listeners for styling buttons
  boldButton.addEventListener('click', () => applyFormatting('b'));
  italicButton.addEventListener('click', () => applyFormatting('i'));
  underlineButton.addEventListener('click', () => applyFormatting('u'));
  strikethroughButton.addEventListener('click', () => applyFormatting('s'));
  hyperlinkButton.addEventListener('click', addHyperlink);
  superscriptButton.addEventListener('click', () => applyFormatting('sup'));
  subscriptButton.addEventListener('click', () => applyFormatting('sub'));
  smallButton.addEventListener('click', () => applyFormatting('small'));
  bigButton.addEventListener('click', () => applyFormatting('big'));
  colourButton.addEventListener('click', addColour);
  overlineButton.addEventListener('click', addOverline);
  codeButton.addEventListener('click', () => applyFormatting('code'));
  lineBreakButton.addEventListener('click', addLineBreak);
  highlightButton.addEventListener('click', addHighlight);
  tooltipButton.addEventListener('click', addTooltip);
  cursorButton.addEventListener('click', addCustomCursor);
  usernameButton.addEventListener('click', addUsername);
  thinButton.addEventListener('click', () => applyFormatting('thin'));
  discreetHyperlinkButton.addEventListener('click', addDiscreetHyperlink);
  smallerButton.addEventListener('click', addSmaller);
  biggerButton.addEventListener('click', addBigger);

  function replaceEmojis(text) {
    // Regex to match emoji keywords between colons (e.g., :smile:)
    return text.replace(/:([a-zA-Z0-9_]+):/g, (match, emojiName) => {
      const emojiPath = `emoji/${emojiName}.png`; // Path to the emoji image
      return `<img src="${emojiPath}" alt="${emojiName}" class="emoji" title="${emojiName}"/>`;
    });
  }

  // Checkbox element
  const toggleFeatureCheckbox = document.getElementById('toggle-feature');

  // Load checkbox state from storage
  const featureEnabled = await loadCheckboxState();
  toggleFeatureCheckbox.checked = featureEnabled;

  // Save checkbox state when toggled
  toggleFeatureCheckbox.addEventListener('change', async () => {
    await saveCheckboxState(toggleFeatureCheckbox.checked);
  });

  // Function to load checkbox state
  async function loadCheckboxState() {
    return new Promise((resolve) => {
      chrome.storage.local.get('featureEnabled', (result) => {
        resolve(result.featureEnabled ?? false); // Default to false if not set
      });
    });
  }

  // Function to save checkbox state
  async function saveCheckboxState(enabled) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ featureEnabled: enabled }, () => {
        resolve();
      });
    });
  }

  // Initialize featureEnabled state if it doesn't exist
  chrome.storage.local.get('featureEnabled', (result) => {
    if (result.featureEnabled === undefined) {
      chrome.storage.local.set({ featureEnabled: false });
    }
  });

  // Ensure the checkbox and other elements exist
  if (!toggleRandomPictureCheckbox || !randomPictureContainer || !randomPicture) {
    console.error('Required DOM elements not found');
    return;
  }

  const names = ['shadow', 'skye', 'dixie', 'sami', 'rylen']; // List of names in the desired order
  const maxNumbers = [15, 17, 18, 15, 1]; // Corresponding maximum numbers for each name

  // Initialize the state
  async function initializeState() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);

    // Initialize the state if it doesn't exist
    if (currentIndex === undefined || currentNumber === undefined) {
      await chrome.storage.local.set({ currentIndex: 0, currentNumber: 1 });
      console.log('State initialized:', { currentIndex: 0, currentNumber: 1 }); // Debug log
    } else {
      console.log('State loaded:', { currentIndex, currentNumber }); // Debug log
    }
  }

  // Update the state
  async function updateState() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);
    console.log('Current state:', { currentIndex, currentNumber }); // Debug log

    if (currentIndex === undefined || currentNumber === undefined) {
      console.error('State is undefined. Initializing state...');
      await initializeState();
      return;
    }

    let newIndex = currentIndex + 1; // Move to the next name
    let newNumber = currentNumber;

    // If we've cycled through all names, reset the index
    if (newIndex >= names.length) {
      newIndex = 0; // Reset to the first name
    }

    // Generate a random number within the range [1, maxNumbers[newIndex]]
    newNumber = Math.floor(Math.random() * maxNumbers[newIndex]) + 1;

    // Save the updated state
    await chrome.storage.local.set({ currentIndex: newIndex, currentNumber: newNumber });
    console.log('Updated state:', { currentIndex: newIndex, currentNumber: newNumber }); // Debug log

    return { currentIndex: newIndex, currentNumber: newNumber };
  }

  // Get the daily picture URL and info
  async function getDailyPictureUrl() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);
    console.log('Fetching picture URL for:', { currentIndex, currentNumber }); // Debug log

    if (currentIndex === undefined || currentNumber === undefined) {
      console.error('State is undefined. Initializing state...');
      await initializeState();
      return;
    }

    const name = names[currentIndex];
    const number = currentNumber;

    // Construct the image URL
    const imageUrl = `https://raw.githubusercontent.com/Dominicp16/cates-for-schwimmble/main/${name}${number}.jpg`;
    return { imageUrl, name, number };
  }

  toggleRandomPictureCheckbox.addEventListener('change', async () => {
    if (toggleRandomPictureCheckbox.checked) {
      // Fetch and display the daily picture
      const { imageUrl, name, number } = await getDailyPictureUrl();
      if (imageUrl) {
        randomPicture.src = imageUrl;
        randomPictureContainer.style.display = 'block';

        // Update the text below the image
        pictureInfo.textContent = `${name} picture #${number}`;

        // Update the state for the next day
        await updateState();
      } else {
        alert('Failed to load the daily picture.');
        toggleRandomPictureCheckbox.checked = false; // Uncheck the checkbox
      }
    } else {
      // Hide the daily picture and text
      randomPictureContainer.style.display = 'none';
    }
  });

  // Initialize the extension
  document.addEventListener('DOMContentLoaded', async () => {
    // Initialize the state
    await initializeState();
    await loadLockoutState(); // Load any existing lockout state

    //await initializePrivilegedUsers(); ENABLE WHEN THE PRIVILEGED USERS BUG IS FIXED

    if (lockoutEndTime > Date.now()) {
      isLoginLocked = true;
      startLockoutTimer(lockoutEndTime - Date.now());
    }

    // Load the checkbox state
    const { featureEnabled } = await chrome.storage.local.get('featureEnabled');
    toggleRandomPictureCheckbox.checked = featureEnabled || false; // Default to false if not set

    // Load the current picture if the checkbox is checked
    if (toggleRandomPictureCheckbox.checked) {
      const { imageUrl, name, number } = await getDailyPictureUrl();
      if (imageUrl) {
        randomPicture.src = imageUrl;
        randomPictureContainer.style.display = 'block';

        // Update the text below the image
        pictureInfo.textContent = `${name} picture #${number}`;
      }
    }
  });

  function reverseString(str) {
    var newString = "";
    for (var i = str.length - 1; i >= 0; i--) {
      newString += str[i];
    }
    return newString;
  }

  async function fetchLatestVersion() {
    const url = 'https://api.github.com/repos/Dominicp16/Schwimmble/contents/latest-version.txt';
    try {
      const response = await fetch(url);
      const data = await response.json();
      const version = atob(data.content); // Decode the base64 content
      return version.trim(); // Remove any extra whitespace
    } catch (error) {
      console.error('Error fetching latest version:', error);
      return null;
    }
  }

  async function checkVersion() {
    const currentVersion = chrome.runtime.getManifest().version;
    const latestVersion = await fetchLatestVersion();
    showOutdatedPopup(latestVersion, currentVersion);
  }


  function showOutdatedPopup(latestVersion, currentVersion) {
    versionNumber.innerHTML = `v${currentVersion}`

    const currentVersionNumerical = reverseString(splitString(reverseString(currentVersion), ".").join(""))
    const latestVersionNumerical = reverseString(splitString(reverseString(latestVersion), ".").join(""))

    if (currentVersionNumerical > latestVersionNumerical) {
      versionNumber.style.color = 'lime'
      versionNumber.innerHTML = `v${currentVersion}-beta`
    }

    if (currentVersion !== latestVersion) {
      if (latestVersionNumerical > currentVersionNumerical) {
        const popup = document.createElement('div');
        popup.className = 'popup-overlay';
        popup.innerHTML = `
      <div class="popup-content">
        <p style="color:black;">A new version (${latestVersion}) is available!</p>
        <a href="https://github.com/Dominicp16/Schwimmble/raw/refs/heads/main/schwimmble-${latestVersion}.zip" target="_blank">
          <button>Download Latest Version</button>
        </a>
      </div>
    `;
        document.body.appendChild(popup);
      }
    }
  }

  checkVersion();


  // Restore the saved message when the popup is opened
  const { draftMessage } = await chrome.storage.local.get('draftMessage');
  if (draftMessage) {
    messageInput.value = draftMessage;
  }

  // Save the message whenever the user types
  messageInput.addEventListener('input', async () => {
    const message = messageInput.value;
    await chrome.storage.local.set({ draftMessage: message });
  });

  // Clear the draft when sending a message
  sendButton.addEventListener('click', async () => {
    const message = messageInput.value;

    // Count existing <big> tags
    const bigTagCount = (message.match(/<big>/gi) || []).length;

    if (bigTagCount > MAX_BIG_TAGS) {
      alert(`Maximum ${MAX_BIG_TAGS} <big> tags allowed. You have ${bigTagCount}.`);
      return;
    }

    if (message.length > MAX_MESSAGE_LENGTH) {
      alert(`Message too long! Maximum ${MAX_MESSAGE_LENGTH} characters allowed.`);
      return;
    }

    if (message) {
      const newMessage = await sendMessage(message);
      if (newMessage) {
        // Clear the saved draft message
        await chrome.storage.local.remove('draftMessage');
        messageInput.value = ''; // Clear the input field
        updateCharacterCounter()
      }
    } else {
      return
    }

    await updateMessageCount();
  });

  function isLoginScreenVisible() {
    return authSection.style.display !== 'none';
  }

  function isMessagingScreenVisible() {
    return messagingSection.style.display !== 'none';
  }

  function getCurrentScreen() {
    if (isLoginScreenVisible()) return 'login';
    if (isMessagingScreenVisible()) return 'messaging';
    return 'unknown';
  }

  // Clear the draft when pressing Enter
  messageInput.addEventListener('keydown', async (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      const message = messageInput.value;

      // Count existing <big> tags
      const bigTagCount = (message.match(/<big>/gi) || []).length;

      if (bigTagCount > MAX_BIG_TAGS) {
        alert(`Maximum ${MAX_BIG_TAGS} <big> tags allowed. You have ${bigTagCount}.`);
        return;
      }

      if (message.length > MAX_MESSAGE_LENGTH) {
        alert(`Message too long! Maximum ${MAX_MESSAGE_LENGTH} characters allowed.`);
        return;
      }

      if (message) {
        const newMessage = await sendMessage(message);
        if (newMessage) {
          // Clear the saved draft message
          await chrome.storage.local.remove('draftMessage');
          messageInput.value = ''; // Clear the input field
          updateCharacterCounter()
        }
      } else {
        return
      }
    }

    await updateMessageCount();
  });

  // Add this near the top with your other initialization code
  async function initializePrivilegedUsers() {
    privilegedUsers = await window.supabaseFunctions.fetchPrivilegedUsers();
    console.log('Loaded privileged users:', privilegedUsers);
  }

  // Function to add delete message handler
  function addDeleteMessageHandler(messageElement, messageId) {
    messageElement.addEventListener('click', async (event) => {
      // Check if Alt key is held and Backspace is pressed
      if (event.altKey && event.key === 'Backspace') {
        // Get the current user
        const { currentUserId } = await chrome.storage.local.get('currentUserId');

        // Check if the current user is in the privileged list
        if (privilegedUsers.includes(currentUserId)) {
          // Delete the message
          const { error } = await supabase
            .from('messages')
            .delete()
            .eq('id', messageId);

          if (error) {
            console.error('Error deleting message:', error.message || error);
          } else {
            console.log('Message deleted:', messageId);
            messageElement.remove(); // Remove the message from the UI
          }
        }
      }
    });
  }

  let isHoveringOverMessage = false;
  let isAltKeyPressed = false; // Track whether Alt is currently pressed

  // Function to add hover listeners
  function addHoverListeners(messageElement) {
    messageElement.addEventListener('mouseenter', () => {
      isHoveringOverMessage = true;
    });

    messageElement.addEventListener('mouseleave', () => {
      isHoveringOverMessage = false;
    });
  }

  // Global keydown event listener
  document.addEventListener('keydown', async (event) => {

    // Track Alt key state
    if (event.key === 'Alt') {
      isAltKeyPressed = true;
    }

    // Check for Backspace while Alt is pressed
    if (isAltKeyPressed && event.key === 'Backspace') {

      if (privilegedUsers.length === 0) {
        await initializePrivilegedUsers();
      }

      if (isHoveringOverMessage) {
        const messageElement = document.querySelector('.message:hover');
        if (messageElement) {
          const messageId = messageIdMap.get(messageElement);

          if (!messageId) {
            console.error('Message ID is undefined');
            return;
          }

          // Get the current user
          const { currentUserId } = await chrome.storage.local.get('currentUserId');

          // Check if the current user is in the privileged list
          if (privilegedUsers.includes(currentUserId)) {
            console.log('User has permission to delete messages');

            // Delete the message from the database
            const { error } = await supabase
              .from('messages')
              .delete()
              .eq('id', messageId);

            if (error) {
              console.error('Error deleting message:', error.message || error);
            } else {
              console.log('Message deleted:', messageId);
              messageElement.remove();
              messageIdMap.delete(messageElement);
            }
          }
        }
      }
    }
  });

  // Global keyup event listener to clear Alt key state
  document.addEventListener('keyup', (event) => {

    if (event.key === 'Alt') {
      isAltKeyPressed = false;
    }
  });

  updateCharacterCounter()

  function updateCharacterCounter() {
    const length = messageInput.value.length;
    charCounter.textContent = `${length}/${MAX_MESSAGE_LENGTH}`;

    if (length >= MAX_MESSAGE_LENGTH) {
      charCounter.style.color = 'red'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.9 && length <= MAX_MESSAGE_LENGTH) {
      charCounter.style.color = 'OrangeRed'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.75 && length <= MAX_MESSAGE_LENGTH * 0.9) {
      charCounter.style.color = 'orange'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.6 && length <= MAX_MESSAGE_LENGTH * 0.75) {
      charCounter.style.color = 'gold'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.45 && length <= MAX_MESSAGE_LENGTH * 0.6) {
      charCounter.style.color = 'yellow'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.25 && length <= MAX_MESSAGE_LENGTH * 0.45) {
      charCounter.style.color = 'cyan'
    } else if (length >= MAX_MESSAGE_LENGTH * 0.1 && length <= MAX_MESSAGE_LENGTH * 0.25) {
      charCounter.style.color = 'honeydew'
    } else {
      charCounter.style.color = 'white'
      charCounter.style.fontWeight = 'normal'
    }

    if (length >= 1024) {
      charCounter.style.visibility = 'visible';
    } else {
      charCounter.style.visibility = 'hidden';
    }

    if (length >= MAX_MESSAGE_LENGTH) {
      charCounter.style.fontWeight = '900'
      charCounter.style.fontSize = '11px'
    } else {
      charCounter.style.fontWeight = 'normal'
      charCounter.style.fontSize = '12px'
    }
  }

  messageInput.addEventListener('input', () => {
    updateCharacterCounter()
  });

  // Initialize max display
  bigTagMaxElement.textContent = MAX_BIG_TAGS;
  bigCounter.style.visibility = 'hidden';

  // Update counter on input
  messageInput.addEventListener('input', () => {
    const bigTagCount = (messageInput.value.match(/<big>/gi) || []).length;
    bigTagCountElement.textContent = bigTagCount;

    // Change color if approaching limit
    if (bigTagCount >= MAX_BIG_TAGS) {
      bigCounter.style.color = 'red';
      bigCounter.style.visibility = 'visible';
    } else {
      bigCounter.style.visibility = 'hidden';
    }
  });

  async function updateMessageCount() {
    try {
      const count = await window.supabaseFunctions.getMessageCount();
      messageCountElement.textContent = count.toLocaleString(); // Formats with commas
    } catch (error) {
      console.error('Failed to update message count:', error);
      messageCountElement.textContent = 'Error';
    }
  }

  async function showContextMenu(event, messageElement) {
    //event.preventDefault();

    // Get the message ID from the closest message container
    const messageContainer = messageElement.closest('.message-container');
    if (!messageContainer) return;

    const messageId = messageContainer.dataset.messageId;
    if (!messageId) return;

    // Get current user
    const { currentUserId } = await chrome.storage.local.get('currentUserId');
    if (!currentUserId) return;

    // Get message details from Supabase
    const { data: message, error } = await supabase
      .from('messages')
      .select('*')
      .eq('id', messageId)
      .single();

    if (error || !message) return;

    // Check if user is privileged or owns the message
    const isPrivileged = privilegedUsers.includes(currentUserId);
    const isOwner = currentUserId === message.user_id;

    if (!isPrivileged) {
      console.log('not privileged')
      if (!isOwner) {
        console.log('not privileged or owner')
        return;
      }
      return;
    }

    // Update context menu with message info
    contextMessageId.textContent = `Message ID: ${messageId}`;
    contextUserId.textContent = `User ID: ${message.user_id}`;
    contextDate.textContent = `Date: ${new Date(message.created_at).toLocaleString()}`;

    // Position the context menu
    contextMenu.style.display = 'block';
    contextMenu.style.left = `${event.clientX}px`;
    contextMenu.style.top = `${event.clientY}px`;

    // Store current message info
    currentMessageId = messageId;
    currentMessageUserId = message.user_id;
  }

  function hideContextMenu() {
    contextMenu.style.display = 'none';
    currentMessageId = null;
    currentMessageUserId = null;
  }

  async function handleDeleteMessage() {
    if (!currentMessageId) return;

    // Double-check permissions before deleting
    const hasPermission = await checkMessagePermissions(currentMessageId);
    if (!hasPermission) {
      hideContextMenu();
      return;
    }

    const { error } = await supabase
      .from('messages')
      .delete()
      .eq('id', currentMessageId);

    if (!error) {
      // Remove message from UI
      const messageElement = document.querySelector(`.message-container[data-message-id="${currentMessageId}"]`);
      if (messageElement) {
        messageElement.remove();
      }
    }

    hideContextMenu();
  }

  function hideContextMenu() {
    contextMenu.style.display = 'none';
    currentMessageId = null;
    currentMessageUserId = null;
  }

  contextDelete.addEventListener('click', async () => {
    if (!currentMessageId) return;

    const { error } = await supabase
      .from('messages')
      .delete()
      .eq('id', currentMessageId);

    if (!error) {
      document.querySelector(`.message-container[data-message-id="${currentMessageId}"]`)?.remove();
    }

    contextMenu.style.display = 'none';
  });

  // Close context menu when clicking elsewhere
  document.addEventListener('click', hideContextMenu);

  // Prevent hiding when clicking inside the context menu
  contextMenu.addEventListener('click', (e) => {
    e.stopPropagation();
  });

  // Handle delete button click
  contextDelete.addEventListener('click', handleDeleteMessage);

  // Hide context menu when scrolling
  messagesDiv.addEventListener('scroll', hideContextMenu);

  async function handleContextMenu(e) {
    const messageElement = e.currentTarget;
    const messageId = messageElement.dataset.messageId;

    // Double-check permissions (in case they changed since hover)
    const hasPermission = await checkMessagePermissions(messageId);
    if (!hasPermission) return;

    //e.preventDefault();

    // Get message details from Supabase
    const { data: message, error } = await supabase
      .from('messages')
      .select('*')
      .eq('id', messageId)
      .single();

    if (error || !message) return;

    // Update context menu with message info
    contextMessageId.textContent = `Message ID: ${messageId}`;
    contextUserId.textContent = `User ID: ${message.user_id}`;
    contextDate.textContent = `Date: ${new Date(message.created_at).toLocaleString()}`;

    // Position the context menu
    contextMenu.style.display = 'block';
    contextMenu.style.left = `${e.clientX}px`;
    contextMenu.style.top = `${e.clientY}px`;

    // Store current message info
    currentMessageId = messageId;
    currentMessageUserId = message.user_id;
  }

  async function checkMessagePermissions(messageId) {
    if (!messageId) return false;

    // Get current user
    const { currentUserId } = await chrome.storage.local.get('currentUserId');
    if (!currentUserId) return false;

    // Get message details
    const { data: message, error } = await supabase
      .from('messages')
      .select('user_id')
      .eq('id', messageId)
      .single();

    if (error || !message) return false;

    // Check if user is privileged or owns the message
    const isPrivileged = privilegedUsers.includes(currentUserId);
    const isOwner = currentUserId === message.user_id;

    return isPrivileged || isOwner;
  }

  function showCustomContextMenu(e) {
    e.preventDefault();
    const messageElement = e.currentTarget;

    contextMessageId.textContent = `Message ID: ${messageElement.dataset.messageId}`;
    contextUserId.textContent = `User ID: ${messageElement.dataset.userId}`;
    contextDate.textContent = `Date: ${new Date().toLocaleString()}`;

    contextMenu.style.display = 'block';
    contextMenu.style.left = `${e.clientX}px`;
    contextMenu.style.top = `${e.clientY}px`;

    currentMessageId = messageElement.dataset.messageId;
  }

  function checkMessageCountVisibility() {
    if (getCurrentScreen() == 'login') {
      fullMessageCountElement.style.visibility = 'hidden'
    } else if (getCurrentScreen() == 'messaging') {
      fullMessageCountElement.style.visibility = 'visible'
    } else {
      fullMessageCountElement.style.visibility = 'visible'
      alert('Detected screen invalid:' + getCurrentScreen())
    }
    console.log(getCurrentScreen())
  }

  function checkLoginLock() {
    const now = Date.now();
    if (isLoginLocked && now - lastFailedAttemptTime < currentWaitTime) {
      const remainingTime = Math.ceil((currentWaitTime - (now - lastFailedAttemptTime)) / 1000);
      authError.textContent = `Too many attempts. Please wait ${remainingTime} seconds.`;
      return true;
    }

    if (!isLoginLocked) return false;

    if (Date.now() < lockoutEndTime) {
      return true;
    }

    isLoginLocked = false;
    return false;
  }

  function startLockoutTimer(duration) {
    lockoutEndTime = Date.now() + duration;
    saveLockoutState();

    const timer = setInterval(() => {
      const remaining = lockoutEndTime - Date.now();
      if (remaining <= 0) {
        clearInterval(timer);
        isLoginLocked = false;
        authError.textContent = "You have 2 more login attempts";
        authSection.classList.remove('locked');
      } else {
        authError.textContent = `Too many attempts. Please wait ${Math.ceil(remaining / 1000)} seconds.`;
      }
    }, 1000);
  }

  function updateLoginAttempts(failed = true) {
    if (failed) {
      loginAttempts++;

      if (loginAttempts >= 4 && (loginAttempts - 4) % 2 === 0) {
        currentLockoutLevel = Math.min(currentLockoutLevel + 1, 5);
        const lockoutDuration = Math.pow(5, currentLockoutLevel) * 1000;
        isLoginLocked = true;
        startLockoutTimer(lockoutDuration);
      }
      saveLockoutState();
    } else {
      // Reset on successful login
      loginAttempts = 0;
      currentLockoutLevel = 0;
      lockoutEndTime = 0;
      isLoginLocked = false;
      chrome.storage.local.remove('loginSecurity');
    }
  }

  async function saveLockoutState() {
    await chrome.storage.local.set({
      loginSecurity: {
        attempts: loginAttempts,
        level: currentLockoutLevel,
        endTime: lockoutEndTime
      }
    });
  }

  async function loadLockoutState() {
    const { loginSecurity } = await chrome.storage.local.get('loginSecurity');
    if (loginSecurity) {
      loginAttempts = loginSecurity.attempts || 0;
      currentLockoutLevel = loginSecurity.level || 0;
      lockoutEndTime = loginSecurity.endTime || 0;

      // Re-activate lockout if still in progress
      if (lockoutEndTime > Date.now()) {
        startLockoutTimer(lockoutEndTime - Date.now());
      }
    }
  }



  checkMessageCountVisibility()
  messagesDiv.scrollTop = messagesDiv.scrollHeight; // Scroll to the bottom
});