console.log('Service worker started'); // Debug log

// Load Supabase client library
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// Initialize Supabase client
const SUPABASE_URL = 'https://gxpffhxrgkbgwukrlrcl.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4cGZmaHhyZ2tiZ3d1a3JscmNsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzk0ODUzODIsImV4cCI6MjA1NTA2MTM4Mn0.YGNYi-7uQF7-1KIiEM8plpyGpfXoXhck66PhfhoatJg';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
console.log('Supabase client initialized:', supabase); // Debug log

// Function to subscribe to real-time updates
function subscribeToMessages(callback) {
  console.log('Subscribing to real-time updates...'); // Debug log
  return supabase
    .channel('messages') // Ensure this channel name is unique
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages' },
      (payload) => {
        console.log('New message received:', payload.new); // Debug log
        callback(payload.new);
      }
    )
    .subscribe((status) => {
      console.log('Subscription status:', status); // Debug log for subscription status
    });
}

// Function to show a notification
function showNotification(message) {
  console.log('Showing notification:', message);
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `New Message from ${message.username}`,
    message: message.text,
  });
}

// Start real-time subscription
let messagesSubscription;
async function startRealTimeUpdates() {
  console.log('Starting real-time updates...'); // Debug log
  messagesSubscription = subscribeToMessages(async (newMessage) => {
    const { currentUserId } = await chrome.storage.local.get('currentUserId');
    if (newMessage.user_id !== currentUserId) { // Only show notifications for other users' messages
      chrome.storage.local.get('featureEnabled', (result) => {
        console.log('Feature enabled state:', result.featureEnabled); // Debug log
        if (result.featureEnabled) {
          showNotification(newMessage);
        }
      });
    } else {
      console.log('Ignoring own message:', newMessage); // Debug log
    }
  });
}

// Keep the service worker alive
setInterval(() => {
  console.log('Service worker heartbeat'); // Debug log
}, 60 * 1000); // Run every 60 seconds

// Reinitialize on service worker restart
chrome.runtime.onStartup.addListener(() => {
  console.log('Service worker started. Reinitializing Supabase...');
  startRealTimeUpdates();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed. Initializing Supabase...');
  startRealTimeUpdates();
});

// Initialize on script load
console.log('Starting real-time updates...'); // Debug log
startRealTimeUpdates();