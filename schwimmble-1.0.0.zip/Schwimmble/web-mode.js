const randomPictureContainerWeb = document.getElementById('random-picture-container-web-mode');
const pictureInfoWeb = document.getElementById('picture-info-web-mode');
const randomPictureWeb = document.getElementById('random-picture-web-mode');

async function webModeRandomPicture() {
    const names = ['shadow', 'skye', 'dixie', 'sami']; // List of names in the desired order
    const maxNumbers = [12, 13, 12, 12]; // Corresponding maximum numbers for each name

    function getRandomInt(max) {
        return Math.floor(Math.random() * max) + 1;
      }
      

    let i = Math.floor(Math.random() * names.length);

    let name = names[i]
    let number = getRandomInt(maxNumbers[i])

    let imageUrl = `https://raw.githubusercontent.com/Dominicp16/cates-for-schwimmble/main/${name}${number}.jpg`;

      randomPictureWeb.src = imageUrl;
      randomPictureContainerWeb.style.display = 'block';

      // Update the text below the image
      pictureInfoWeb.textContent = `${name} picture #${number}`;
}

webModeRandomPicture()