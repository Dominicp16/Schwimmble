document.addEventListener('DOMContentLoaded', async () => {
  const toggleRandomPictureCheckbox = document.getElementById('toggle-random-picture');
  const randomPictureContainer = document.getElementById('random-picture-container');
  const pictureInfo = document.getElementById('picture-info');
  const randomPicture = document.getElementById('random-picture');
  const authSection = document.getElementById('auth-section');
  const messagingSection = document.getElementById('messaging-section');
  const emailInput = document.getElementById('email-input');
  const passwordInput = document.getElementById('password-input');
  const usernameInput = document.getElementById('username-input');
  const loginButton = document.getElementById('login-button');
  const signupButton = document.getElementById('signup-button');
  const logoutButton = document.getElementById('logout-button');
  const authError = document.getElementById('auth-error');
  const messagesDiv = document.getElementById('messages');
  const messageInput = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');

  // Styling menu elements
  const toggleStylingMenuCheckbox = document.getElementById('toggle-styling-menu');
  const stylingMenu = document.getElementById('styling-menu');

  // Styling menu buttons
  const boldButton = document.getElementById('bold-button');
  const italicButton = document.getElementById('italic-button');
  const underlineButton = document.getElementById('underline-button');
  const strikethroughButton = document.getElementById('strikethrough-button');
  const hyperlinkButton = document.getElementById('hyperlink-button');
  const superscriptButton = document.getElementById('superscript-button');
  const subscriptButton = document.getElementById('subscript-button');
  const smallButton = document.getElementById('small-button');
  const bigButton = document.getElementById('big-button');
  const colourButton = document.getElementById('colour-button');
  const overlineButton = document.getElementById('overline-button');
  const codeButton = document.getElementById('code-button');
  const lineBreakButton = document.getElementById('line-break-button');
  const highlightButton = document.getElementById('highlight-button');
  const tooltipButton = document.getElementById('tooltip-button');
  const cursorButton = document.getElementById('cursor-button');
  const usernameButton = document.getElementById('username-button');
  const thinButton = document.getElementById('thin-button');
  const discreetHyperlinkButton = document.getElementById('discreet-hyperlink-button');
  const smallerButton = document.getElementById('smaller-button');
  const biggerButton = document.getElementById('bigger-button');


  let messagesSubscription;
  const sentMessageIds = new Set(); // Track IDs of messages already displayed

  const messageIdMap = new Map(); // Maps message elements to their IDs

  // Check if user is already logged in
  const user = await checkAuth();
  if (user) {
    currentUser = user;
    showMessagingSection();
    await loadMessages(); // Load existing messages
    messagesSubscription = subscribeToMessages(handleNewMessage); // Subscribe to real-time updates
  }

  // Login button click
  loginButton.addEventListener('click', async () => {
    const email = emailInput.value;
    const password = passwordInput.value;
    const result = await login(email, password);
    if (result.error) {
      authError.textContent = result.error.message;
    } else {
      currentUser = result; // Set the current user
      showMessagingSection(); // Show the messaging section
      await loadMessages(); // Load existing messages
      messagesSubscription = subscribeToMessages(handleNewMessage); // Subscribe to real-time updates
    }
  });

  // Signup button click
  signupButton.addEventListener('click', async () => {
    const email = emailInput.value;
    const password = passwordInput.value;
    const username = usernameInput.value; // Get username
    const result = await signup(email, password, username);
    if (result.error) {
      authError.textContent = result.error.message;
    } else {
      authError.textContent = 'Please check your email to confirm your account. The link sent will show up as blocked, but you can then open the extension again and log in.';
    }
  });

  // Logout button click
  logoutButton.addEventListener('click', async () => {
    await logout();
    showAuthSection();
    // Unsubscribe from real-time updates
    if (messagesSubscription) {
      unsubscribeFromMessages(messagesSubscription);
    }
  });

  // Show messaging section
  function showMessagingSection() {
    authSection.style.display = 'none';
    messagingSection.style.display = 'block';
  }

  // Show auth section
  function showAuthSection() {
    authSection.style.display = 'block';
    messagingSection.style.display = 'none';
  }

  // Function to fetch messages
  async function fetchMessages() {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching messages:', error.message || error);
    } else {
      console.log('Fetched messages:', data); // Debug log
      return data;
    }
  }

  function splitString(inputString, splitString) {
    const splitIndex = inputString.indexOf(splitString);

    if (splitIndex === -1) {
      return ["", inputString];
    }

    const beforeSplit = inputString.slice(0, splitIndex);
    const afterSplit = inputString.slice(splitIndex + splitString.length);

    return [beforeSplit, afterSplit];
  }

  // Function to format a date as dd/mm/yy
  function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0'); // Ensure two digits
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
    const year = String(date.getFullYear()).slice(-2); // Get last two digits of the year
    return `${day}/${month}/${year}`;
  }

  // Load messages
  async function loadMessages() {
    const messages = await fetchMessages();
    messagesDiv.innerHTML = messages
      .map((msg) => {
        const messageDate = new Date(msg.created_at);
        const now = new Date();

        // Check if the message is more than a day old
        const isMoreThanADayOld = (now - messageDate) > 24 * 60 * 60 * 1000;

        // Format the date if the message is more than a day old
        const dateString = isMoreThanADayOld ? ` ${formatDate(messageDate)}` : '';

        return `
          <div>
            ${splitString(msg.text, "</username>")[0]}<strong class="${msg.user_id === currentUser.id ? 'message-self' : 'message'}">〈${msg.username}〉: </strong> ${replaceEmojis(splitString(msg.text, "</username>")[1])} 
            <small><em>(${new Date(msg.created_at).toLocaleTimeString()} ${dateString})</em></small>
          </div>
        `
      })
      .join('');

    // Add delete handlers to all loaded messages
    messagesDiv.querySelectorAll('.message').forEach((messageElement) => {
      const messageId = messageElement.dataset.messageId;
      addDeleteMessageHandler(messageElement, messageId);
    });

    // Add hover listeners and store message IDs in the map
    messagesDiv.querySelectorAll('.message').forEach((messageElement, index) => {
      const messageId = messages[index].id; // Get the message ID from the fetched data
      messageIdMap.set(messageElement, messageId); // Store the ID in the map

      console.log('Message element:', messageElement); // Debug log
      console.log('Message ID:', messageId); // Debug log

      addHoverListeners(messageElement);
    });

    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Scroll to the bottom
  }

  function formatTimestamp(timestamp) {
    const now = new Date();
    const messageDate = new Date(timestamp);
    const isToday = now.toDateString() === messageDate.toDateString();

    if (isToday) {
      return messageDate.toLocaleTimeString();
    } else {
      return messageDate.toLocaleDateString();
    }
  }

  // Function to handle new messages
  function handleNewMessage(newMessage) {
    if (sentMessageIds.has(newMessage.id)) {
      // Skip if the message has already been displayed
      return;
    }
    sentMessageIds.add(newMessage.id); // Track the message ID

    const messageElement = document.createElement('div');
    messageElement.dataset.messageId = newMessage.id; // Add data-message-id attribute
    const timestamp = new Date(newMessage.created_at).toLocaleTimeString();

    // Replace emoji keywords with emoji images
    const messageText = replaceEmojis(newMessage.text);

    messageElement.innerHTML = `
       ${splitString(messageText, "</username>")[0]}<strong class="${newMessage.user_id === currentUser.id ? 'message-self' : 'message'}">〈${newMessage.username}〉: </strong> ${splitString(messageText, "</username>")[1]}
      <small><em>(${timestamp})</em></small>
    `;
    messagesDiv.appendChild(messageElement);

    // Add the delete handler to the message element
    addDeleteMessageHandler(messageElement, newMessage.id);

    // Add hover listeners to the new message
    addHoverListeners(messageElement);

    // Append the new message to the messages container
    messagesDiv.appendChild(messageElement);

    // Wait for all images in the message to load before scrolling
    const images = messageElement.getElementsByTagName('img');
    let imagesLoaded = 0;

    if (images.length > 0) {
      for (const img of images) {
        img.onload = () => {
          imagesLoaded++;
          if (imagesLoaded === images.length) {
            // All images have loaded, scroll to the bottom
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
          }
        };
      }
    } else {
      // No images, scroll immediately
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    // Use a MutationObserver to scroll to the bottom after the message is fully rendered
    const observer = new MutationObserver((mutationsList, observer) => {
      for (const mutation of mutationsList) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          // Scroll to the bottom after the new message is added
          messagesDiv.scrollTop = messagesDiv.scrollHeight;
          observer.disconnect(); // Stop observing once the scroll is done
        }
      }
    });



    // Start observing the messages container for changes
    observer.observe(messagesDiv, { childList: true });
  }

  stylingMenu.style.display = 'none'

  // Toggle styling menu visibility
  toggleStylingMenuCheckbox.addEventListener('change', () => {
    stylingMenu.style.display = toggleStylingMenuCheckbox.checked ? 'flex' : 'none';
    console.log(toggleStylingMenuCheckbox.checked ? 'flex' : 'none')
  });


  // Function to apply formatting to selected text
  function applyFormatting(tag) {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const formattedText = `<${tag}>${selectedText}</${tag}>`;
      messageInput.setRangeText(formattedText, start, end, 'end');
    }
  }

  // Add keybind event listeners
  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.metaKey) { // Check for Alt (Windows/Linux) or Option (Mac)
      const messageInput = document.getElementById('message-input');
      if (messageInput === document.activeElement) { // Ensure the input field is focused
        switch (event.key.toLowerCase()) {
          case 'b': // Bold (Alt+B or Option+B)
            applyFormatting('b');
            event.preventDefault(); // Prevent default browser behavior
            break;
          case 'i': // Italic (Alt+I or Option+I)
            applyFormatting('i');
            event.preventDefault();
            break;
          case 'u': // Underline (Alt+U or Option+U)
            applyFormatting('u');
            event.preventDefault();
            break;
          case 's': // Strikethrough (Alt+S or Option+S)
            applyFormatting('s');
            event.preventDefault();
            break;
          case 'l': // Line break (Alt+L or Option+L)
            addLineBreak();
            event.preventDefault();
            break;
          case '.': // Superscript (Alt+. or Option+.)
            applyFormatting('sup');
            event.preventDefault();
            break;
          case ',': // Subscript (Alt+, or Option+,)
            applyFormatting('sub');
            event.preventDefault();
            break;
          case 'h': // Hyperlink (Alt+h or Option+h)
            addHyperlink();
            event.preventDefault();
            break;
        }
      }
    }
  });

  // Function to add a hyperlink
  function addHyperlink() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const url = prompt('Enter the URL:');
      if (url) {
        const hyperlink = `<a href="${url}" target="_blank">${selectedText}</a>`;
        messageInput.setRangeText(hyperlink, start, end, 'end');
      }
    }
  }

  // Function to add a colour
  function addColour() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const colour = prompt('Enter the colour:');
      if (colour) {
        const coloured = `<span style="color:${colour};">${selectedText}</span>`;
        messageInput.setRangeText(coloured, start, end, 'end');
      }
    }
  }

  // Function to add an overline
  function addOverline() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const overline = `<span style="text-decoration:overline;">${selectedText}</span>`;
      messageInput.setRangeText(overline, start, end, 'end');
    }
  }

  // Function to add a line break
  function addLineBreak() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;

    const broken = `<br>‌  `;
    messageInput.setRangeText(broken, start, end, 'end');
  }

  // Function to add a highlight
  function addHighlight() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const highlight = prompt('Enter the highlight colour:');
      if (highlight) {
        const highlighted = `<mark style="background-color:${highlight};">${selectedText}</mark>`;
        messageInput.setRangeText(highlighted, start, end, 'end');
      }
    }
  }

  // Function to add a tooltip
  function addTooltip() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const tooltip = prompt('Enter the tooltip:');
      if (tooltip) {
        const tooltipped = `<span title="${tooltip}">${selectedText}</span>`;
        messageInput.setRangeText(tooltipped, start, end, 'end');
      }
    }
  }

  // Function to add a cursor
  function addCustomCursor() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const cursor = prompt('Enter the cursor:');
      if (cursor) {
        const customCursor = `<cc type="${cursor}">${selectedText}</cc>`;
        messageInput.setRangeText(customCursor, start, end, 'end');
      }
    }
  }

  // Function to add the username
  function addUsername() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;

    const username = `</username>`;
    messageInput.setRangeText(username, start, end, 'end');
  }

  // Function to add a discreet hyperlink
  function addDiscreetHyperlink() {
    const messageInput = document.getElementById('message-input');
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const url = prompt('Enter the URL:');
      if (url) {
        const hyperlink = `<a href="${url}" target="_blank" style="text-decoration:none; color:white;">${selectedText}</a>`;
        messageInput.setRangeText(hyperlink, start, end, 'end');
      }
    }
  }

  // Function make text smaller
  function addSmaller() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const smaller = `<small><small>${selectedText}</small></small>`;
      messageInput.setRangeText(smaller, start, end, 'end');
    }
  }

  // Function make text bigger
  function addBigger() {
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const selectedText = messageInput.value.substring(start, end);

    if (selectedText) {
      const bigger = `<big><big>${selectedText}</big></big>`;
      messageInput.setRangeText(bigger, start, end, 'end');
    }
  }

  // Add event listeners for styling buttons
  boldButton.addEventListener('click', () => applyFormatting('b'));
  italicButton.addEventListener('click', () => applyFormatting('i'));
  underlineButton.addEventListener('click', () => applyFormatting('u'));
  strikethroughButton.addEventListener('click', () => applyFormatting('s'));
  hyperlinkButton.addEventListener('click', addHyperlink);
  superscriptButton.addEventListener('click', () => applyFormatting('sup'));
  subscriptButton.addEventListener('click', () => applyFormatting('sub'));
  smallButton.addEventListener('click', () => applyFormatting('small'));
  bigButton.addEventListener('click', () => applyFormatting('big'));
  colourButton.addEventListener('click', addColour);
  overlineButton.addEventListener('click', addOverline);
  codeButton.addEventListener('click', () => applyFormatting('code'));
  lineBreakButton.addEventListener('click', addLineBreak);
  highlightButton.addEventListener('click', addHighlight);
  tooltipButton.addEventListener('click', addTooltip);
  cursorButton.addEventListener('click', addCustomCursor);
  usernameButton.addEventListener('click', addUsername);
  thinButton.addEventListener('click', () => applyFormatting('thin'));
  discreetHyperlinkButton.addEventListener('click', addDiscreetHyperlink);
  smallerButton.addEventListener('click', addSmaller);
  biggerButton.addEventListener('click', addBigger);

  function replaceEmojis(text) {
    // Regex to match emoji keywords between colons (e.g., :smile:)
    return text.replace(/:([a-zA-Z0-9_]+):/g, (match, emojiName) => {
      const emojiPath = `emoji/${emojiName}.png`; // Path to the emoji image
      return `<img src="${emojiPath}" alt="${emojiName}" class="emoji" />`;
    });
  }

  // Checkbox element
  const toggleFeatureCheckbox = document.getElementById('toggle-feature');

  // Load checkbox state from storage
  const featureEnabled = await loadCheckboxState();
  toggleFeatureCheckbox.checked = featureEnabled;

  // Save checkbox state when toggled
  toggleFeatureCheckbox.addEventListener('change', async () => {
    await saveCheckboxState(toggleFeatureCheckbox.checked);
  });

  // Function to load checkbox state
  async function loadCheckboxState() {
    return new Promise((resolve) => {
      chrome.storage.local.get('featureEnabled', (result) => {
        resolve(result.featureEnabled ?? false); // Default to false if not set
      });
    });
  }

  // Function to save checkbox state
  async function saveCheckboxState(enabled) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ featureEnabled: enabled }, () => {
        resolve();
      });
    });
  }

  // Initialize featureEnabled state if it doesn't exist
  chrome.storage.local.get('featureEnabled', (result) => {
    if (result.featureEnabled === undefined) {
      chrome.storage.local.set({ featureEnabled: false });
    }
  });

  // Ensure the checkbox and other elements exist
  if (!toggleRandomPictureCheckbox || !randomPictureContainer || !randomPicture) {
    console.error('Required DOM elements not found');
    return;
  }

  const names = ['shadow', 'skye', 'dixie', 'sami']; // List of names in the desired order
  const maxNumbers = [14, 14, 16, 13]; // Corresponding maximum numbers for each name

  // Initialize the state
  async function initializeState() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);

    // Initialize the state if it doesn't exist
    if (currentIndex === undefined || currentNumber === undefined) {
      await chrome.storage.local.set({ currentIndex: 0, currentNumber: 1 });
      console.log('State initialized:', { currentIndex: 0, currentNumber: 1 }); // Debug log
    } else {
      console.log('State loaded:', { currentIndex, currentNumber }); // Debug log
    }
  }

  // Update the state
  async function updateState() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);
    console.log('Current state:', { currentIndex, currentNumber }); // Debug log

    if (currentIndex === undefined || currentNumber === undefined) {
      console.error('State is undefined. Initializing state...');
      await initializeState();
      return;
    }

    let newIndex = currentIndex + 1; // Move to the next name
    let newNumber = currentNumber;

    // If we've cycled through all names, reset the index
    if (newIndex >= names.length) {
      newIndex = 0; // Reset to the first name
    }

    // Generate a random number within the range [1, maxNumbers[newIndex]]
    newNumber = Math.floor(Math.random() * maxNumbers[newIndex]) + 1;

    // Save the updated state
    await chrome.storage.local.set({ currentIndex: newIndex, currentNumber: newNumber });
    console.log('Updated state:', { currentIndex: newIndex, currentNumber: newNumber }); // Debug log

    return { currentIndex: newIndex, currentNumber: newNumber };
  }

  // Get the daily picture URL and info
  async function getDailyPictureUrl() {
    const { currentIndex, currentNumber } = await chrome.storage.local.get(['currentIndex', 'currentNumber']);
    console.log('Fetching picture URL for:', { currentIndex, currentNumber }); // Debug log

    if (currentIndex === undefined || currentNumber === undefined) {
      console.error('State is undefined. Initializing state...');
      await initializeState();
      return;
    }

    const name = names[currentIndex];
    const number = currentNumber;

    // Construct the image URL
    const imageUrl = `https://raw.githubusercontent.com/Dominicp16/cates-for-schwimmble/main/${name}${number}.jpg`;
    return { imageUrl, name, number };
  }

  toggleRandomPictureCheckbox.addEventListener('change', async () => {
    if (toggleRandomPictureCheckbox.checked) {
      // Fetch and display the daily picture
      const { imageUrl, name, number } = await getDailyPictureUrl();
      if (imageUrl) {
        randomPicture.src = imageUrl;
        randomPictureContainer.style.display = 'block';

        // Update the text below the image
        pictureInfo.textContent = `${name} picture #${number}`;

        // Update the state for the next day
        await updateState();
      } else {
        alert('Failed to load the daily picture.');
        toggleRandomPictureCheckbox.checked = false; // Uncheck the checkbox
      }
    } else {
      // Hide the daily picture and text
      randomPictureContainer.style.display = 'none';
    }
  });

  // Initialize the extension
  document.addEventListener('DOMContentLoaded', async () => {
    // Initialize the state
    await initializeState();

    // Load the checkbox state
    const { featureEnabled } = await chrome.storage.local.get('featureEnabled');
    toggleRandomPictureCheckbox.checked = featureEnabled || false; // Default to false if not set

    // Load the current picture if the checkbox is checked
    if (toggleRandomPictureCheckbox.checked) {
      const { imageUrl, name, number } = await getDailyPictureUrl();
      if (imageUrl) {
        randomPicture.src = imageUrl;
        randomPictureContainer.style.display = 'block';

        // Update the text below the image
        pictureInfo.textContent = `${name} picture #${number}`;
      }
    }
  });

  function reverseString(str) {
    var newString = "";
    for (var i = str.length - 1; i >= 0; i--) {
      newString += str[i];
    }
    return newString;
  }

  async function fetchLatestVersion() {
    const url = 'https://api.github.com/repos/Dominicp16/Schwimmble/contents/latest-version.txt';
    try {
      const response = await fetch(url);
      const data = await response.json();
      const version = atob(data.content); // Decode the base64 content
      return version.trim(); // Remove any extra whitespace
    } catch (error) {
      console.error('Error fetching latest version:', error);
      return null;
    }
  }

  async function checkVersion() {
    const currentVersion = chrome.runtime.getManifest().version;
    const latestVersion = await fetchLatestVersion();
    showOutdatedPopup(latestVersion, currentVersion);
  }

  function showOutdatedPopup(latestVersion, currentVersion) {
    document.getElementById('version-number').innerHTML = `v${currentVersion}`

    const currentVersionNumerical = reverseString(splitString(reverseString(currentVersion), ".").join(""))
    const latestVersionNumerical = reverseString(splitString(reverseString(latestVersion), ".").join(""))

    if (currentVersion !== latestVersion) {
      if (latestVersionNumerical > currentVersionNumerical) {
        const popup = document.createElement('div');
        popup.className = 'popup-overlay';
        popup.innerHTML = `
      <div class="popup-content">
        <p style="color:black;">A new version (${latestVersion}) is available!</p>
        <a href="https://github.com/Dominicp16/Schwimmble/raw/refs/heads/main/schwimmble-${latestVersion}.zip" target="_blank">
          <button>Download Latest Version</button>
        </a>
      </div>
    `;
        document.body.appendChild(popup);
      }
    }
  }

  checkVersion();


  // Restore the saved message when the popup is opened
  const { draftMessage } = await chrome.storage.local.get('draftMessage');
  if (draftMessage) {
    messageInput.value = draftMessage;
  }

  // Save the message whenever the user types
  messageInput.addEventListener('input', async () => {
    const message = messageInput.value;
    await chrome.storage.local.set({ draftMessage: message });
  });

  // Clear the draft when sending a message
  sendButton.addEventListener('click', async () => {
    const message = messageInput.value;
    if (message) {
      const newMessage = await sendMessage(message);
      if (newMessage) {
        // Clear the saved draft message
        await chrome.storage.local.remove('draftMessage');
        messageInput.value = ''; // Clear the input field
      }
    }
  });

  // Clear the draft when pressing Enter
  messageInput.addEventListener('keydown', async (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      const message = messageInput.value;
      if (message) {
        const newMessage = await sendMessage(message);
        if (newMessage) {
          // Clear the saved draft message
          await chrome.storage.local.remove('draftMessage');
          messageInput.value = ''; // Clear the input field
        }
      }
    }
  });

  const privilegedUsers = [
    '86689bb0-9800-4230-a2ce-f83c81558679', // schwimmble_bronson
    'schwimmble_bronson',
  ];

  // Function to add delete message handler
  function addDeleteMessageHandler(messageElement, messageId) {
    messageElement.addEventListener('click', async (event) => {
      // Check if Alt key is held and Backspace is pressed
      if (event.altKey && event.key === 'Backspace') {
        // Get the current user
        const { currentUserId } = await chrome.storage.local.get('currentUserId');

        // Check if the current user is in the privileged list
        if (privilegedUsers.includes(currentUserId)) {
          // Delete the message
          const { error } = await supabase
            .from('messages')
            .delete()
            .eq('id', messageId);

          if (error) {
            console.error('Error deleting message:', error.message || error);
          } else {
            console.log('Message deleted:', messageId);
            messageElement.remove(); // Remove the message from the UI
          }
        } else {
          console.log('User does not have permission to delete messages.');
        }
      }
    });
  }

  let isHoveringOverMessage = false;
  let isAltKeyPressed = false; // Track whether Alt is currently pressed

  // Function to add hover listeners
  function addHoverListeners(messageElement) {
    messageElement.addEventListener('mouseenter', () => {
      console.log('Mouse entered message:', messageIdMap.get(messageElement)); // Debug log
      isHoveringOverMessage = true;
    });

    messageElement.addEventListener('mouseleave', () => {
      console.log('Mouse left message:', messageIdMap.get(messageElement)); // Debug log
      isHoveringOverMessage = false;
    });
  }

  // Global keydown event listener
  document.addEventListener('keydown', async (event) => {
    console.log('Key pressed:', event.key); // Debug log
    console.log('Alt key pressed:', isAltKeyPressed); // Debug log

    // Track Alt key state
    if (event.key === 'Alt') {
      isAltKeyPressed = true;
      console.log('Alt key pressed'); // Debug log
    }

    // Check for Backspace while Alt is pressed
    if (isAltKeyPressed && event.key === 'Backspace') {
      console.log('Backspace pressed while Alt is held'); // Debug log
      console.log('Is hovering over message:', isHoveringOverMessage); // Debug log

      if (isHoveringOverMessage) {
        const messageElement = document.querySelector('.message:hover');
        if (messageElement) {
          const messageId = messageIdMap.get(messageElement); // Get the message ID from the map
          console.log('Message to delete:', messageId); // Debug log

          if (!messageId) {
            console.error('Message ID is undefined'); // Debug log
            return;
          }

          // Get the current user
          const { currentUserId } = await chrome.storage.local.get('currentUserId');
          console.log('Current user:', currentUserId); // Debug log

          // Check if the current user is in the privileged list
          if (privilegedUsers.includes(currentUserId)) {
            console.log('User has permission to delete messages'); // Debug log

            // Delete the message from the database
            const { error } = await supabase
              .from('messages')
              .delete()
              .eq('id', messageId);

            if (error) {
              console.error('Error deleting message:', error.message || error);
            } else {
              console.log('Message deleted:', messageId);
              messageElement.remove(); // Remove the message from the UI
              messageIdMap.delete(messageElement); // Remove the entry from the map
            }
          } else {
            console.log('User does not have permission to delete messages.');
          }
        }
      }
    }
  });

  // Global keyup event listener to clear Alt key state
  document.addEventListener('keyup', (event) => {
    console.log('Key released:', event.key); // Debug log

    if (event.key === 'Alt') {
      isAltKeyPressed = false;
      console.log('Alt key released'); // Debug log
    }
  });
});